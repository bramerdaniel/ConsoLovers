﻿namespace $safeprojectname$
{
   using ConsoLovers.ConsoleToolkit.Core;
   using ConsoLovers.ConsoleToolkit.Core.CommandLineArguments;

   /// <summary>The application logic</summary>
   /// <seealso cref="ConsoLovers.ConsoleToolkit.Core.ConsoleApplication{$safeprojectname$}" />
   internal class $safeprojectname$Application : ConsoleApplication<$safeprojectname$Arguments>
   {
      public $safeprojectname$Application(ICommandLineEngine commandLineEngine)
          : base(commandLineEngine)
      {
      }

      public override void RunWith($safeprojectname$Arguments arguments)
      {
         Console.WriteLine("Hello " + Arguments.UserName);
      }
   }
}