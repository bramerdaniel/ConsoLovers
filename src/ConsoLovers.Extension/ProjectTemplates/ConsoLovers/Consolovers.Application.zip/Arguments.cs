﻿namespace $safeprojectname$
{
   using System.Diagnostics.CodeAnalysis;

   using ConsoLovers.ConsoleToolkit.Core.CommandLineArguments;

   /// <summary>The arguments for the <see cref="$safeprojectname$Application"/></summary>
   [SuppressMessage("ReSharper", "UnusedMember.Global")]
   [SuppressMessage("ReSharper", "UnusedAutoPropertyAccessor.Global")]
   internal class $safeprojectname$Arguments
   {
      #region Public Properties

      [Command("Help", "?")]
      [HelpText("Command that displays this help")]
      public HelpCommand Help { get; set; }

      [Argument("UserName", "un")]
      [HelpText("The name of the user")]
      public string UserName { get; set; }

      [Option("WaitForKey", "wfk")]
      [HelpText("If this flag is set, the application waits for an ENTER before exiting")]
      public bool WaitForKey { get; set; }

      #endregion
   }
}