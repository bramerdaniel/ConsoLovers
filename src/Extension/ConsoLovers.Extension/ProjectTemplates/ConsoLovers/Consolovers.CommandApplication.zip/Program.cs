﻿namespace $safeprojectname$
{
   using ConsoLovers.ConsoleToolkit.Core;

   public static class Programm
   {
      public static void Main(string[] args)
      {
         var application = ConsoleApplicationManager.For<MyApplication>().Run(args);
         if (application.Arguments?.WaitForKey ?? true)
            application.Console.ReadLine();
      }
   }
}