﻿namespace $safeprojectname$
{
   using ConsoLovers.ConsoleToolkit.Core.CommandLineArguments;

   using $safeprojectname$.Commands;

   internal class MyArguments
   {
      #region Public Properties

      [Command("Help", "?")]
      [HelpText("Command that displays this help")]
      public HelpCommand Help { get; set; }

      [Command("Run", "r", IsDefaultCommand = true)]
      [HelpText("Initial command that is executed by default")]
      public RunCommand Run { get; set; }

      [Option("WaitForKey", "wfk")]
      [HelpText("If this flag is set, the application waits for an ENTER before exiting")]
      public bool WaitForKey { get; set; }

      #endregion
   }
}