﻿namespace $safeprojectname$
{
   using ConsoLovers.ConsoleToolkit.Core;
   using ConsoLovers.ConsoleToolkit.Core.CommandLineArguments;

   /// <summary>The application logic</summary>
   internal class MyApplication : ConsoleApplication<MyArguments>
   {
      #region Constructors and Destructors

      public MyApplication(ICommandLineEngine commandLineEngine)
         : base(commandLineEngine)
      {
      }

      #endregion

      #region Public Methods and Operators

      public override void RunWith(MyArguments arguments)
      {
         // Only used when no command is defined
      }

      #endregion
   }
}