﻿namespace $safeprojectname$.Commands
{
   using ConsoLovers.ConsoleToolkit.Core.CommandLineArguments;

   internal class RunArguments
   {
      #region Public Properties

      [Argument("UserName", "un")]
      [HelpText("Displays the user name")]
      public string UserName { get; set; }

      #endregion
   }
}