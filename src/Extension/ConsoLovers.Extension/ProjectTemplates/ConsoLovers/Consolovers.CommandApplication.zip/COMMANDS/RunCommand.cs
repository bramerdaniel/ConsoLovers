﻿namespace $safeprojectname$.Commands
{
   using System;

   using ConsoLovers.ConsoleToolkit.Core.CommandLineArguments;
   
   internal class RunCommand : ICommand<RunArguments>
   {
      #region ICommand<RunArguments> Members
      
      public void Execute()
      {
         Console.WriteLine($"Running for user {Arguments.UserName}");
      }

      public RunArguments Arguments { get; set; }

      #endregion
   }
}